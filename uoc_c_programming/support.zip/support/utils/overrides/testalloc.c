#include <stdio.h>
#include <malloc.h>
#include <stdbool.h>

static size_t _allocations[10] = {0};  // Array of malloc call sizes
static char _memory[1000][1000] = {{0}}; // Memory that I allocate
static int _numAllocations = 0;
static int totalFreed = 0;

static void* my_malloc(size_t size)
{
    _allocations[_numAllocations] = size;
    void *p = &_memory[_numAllocations][0];
    _numAllocations += 1;
    return p;
}

static void* my_realloc(void *ptr, size_t size)
{
    return my_malloc(size);
}

static int my_free(void* p)
{
	int ret = -1;
    for (int i = 0; i < 1000; i++) {
        if (p == &_memory[i][0]) {
            if (_allocations[i] != 0) {
				ret = 0;
				totalFreed += _allocations[i];
                _allocations[i] = 0;
            } else {
				ret = 1;
            }
            return ret;
        }
    }
	ret = 2;
	return ret;
}

/* Prototypes for our hooks.  */
//static void my_init_hook(void);
static void *my_malloc_hook(size_t, const void *);
static void *my_realloc_hook(void *, size_t, const void *);
static void my_free_hook(void *, const void *);

/* Variables to save original hooks. */
static void *(*old_malloc_hook)(size_t, const void *);
static void *(*old_realloc_hook)(void *, size_t, const void *);
static void (*volatile old_free_hook)(void *, const void *);


// This is a hack to get rid of unused function (__check_mem) warning when compiling the answer
static int active = false;

void __check_mem(void)
{
	if (active) {
		printf("Test feedback: total %d bytes freed\n", totalFreed);
	}
}

void my_init_hook(void)
{
    old_malloc_hook = __malloc_hook;
    __malloc_hook = my_malloc_hook;
    old_realloc_hook = __realloc_hook;
    __realloc_hook = my_realloc_hook;
    old_free_hook = __free_hook;
    __free_hook = my_free_hook;
	__check_mem();
	active = true;
}

/* Override initializing hook from the C library. */
void (*volatile __malloc_initialize_hook)(void) = my_init_hook;


static void *my_malloc_hook(size_t size, const void *caller)
{
    void *result;

    /* Restore all old hooks */
    __malloc_hook = old_malloc_hook;

    /* Call recursively */
    result = my_malloc(size);

    /* Save underlying hooks */
    old_malloc_hook = __malloc_hook;

    /* Restore our own hooks */
    __malloc_hook = my_malloc_hook;

    return result;
}

static void *my_realloc_hook(void *ptr, size_t size, const void *caller)
{
    void *result;
    __realloc_hook = old_realloc_hook;
    result = my_realloc(ptr, size);
    old_realloc_hook = __realloc_hook;
	puts("Test feedback: realloc should not be used");
    __realloc_hook = my_realloc_hook;
    return result;
}

static void my_free_hook(void *ptr, const void *caller)
{
    __free_hook = old_free_hook;
    int ret = my_free(ptr);
    old_free_hook = __free_hook;
	if (ret == 0) {
		// Don't give feedback if correct actually
		//puts("Test feedback: free called");
	} else if (ret == 1) {
		puts("Test feedback: free called on already freed block");
	} else if (ret == 2) {
		puts("Test feedback: free called on ptr to non-malloc'd block");
	}
    __free_hook = my_free_hook;
}
