#define _GNU_SOURCE

#include <stdio.h>
#include <dlfcn.h>
#include <stdlib.h>


static FILE* (*original_fopen)(const char*, const char*) = NULL;
static int (*original_fclose)(FILE*) = NULL;
static size_t _file_open_count = 0;

void checkFilesClosed(void)
{
  if (_file_open_count > 0) {
    fprintf(stderr, "Not all files were closed on exit.\n");
  }
}

FILE* fopen(const char *path, const char *mode)
{
  FILE* fileptr;

  if (!original_fopen) {
    original_fopen = (FILE* (*)(const char*, const char*))dlsym(RTLD_NEXT, "fopen");
    original_fclose = (int (*)(FILE*))dlsym(RTLD_NEXT, "fclose");
    atexit(checkFilesClosed);
  }

  fileptr = original_fopen(path, mode);
  if (fileptr!= NULL) {
    _file_open_count++;
  }
  return fileptr;
}

int fclose(FILE* fileptr)
{
  int return_code = original_fclose(fileptr);
  if (return_code == 0) {
    _file_open_count--;
  }
  return return_code;
}
